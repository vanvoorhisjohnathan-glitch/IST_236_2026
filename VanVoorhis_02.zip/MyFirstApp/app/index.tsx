import { StatusBar } from "expo-status-bar";
import {
  Image,
  Linking,
  SafeAreaView,
  StyleSheet,
  Text,
  View,
} from "react-native";

export default function App() {
  return (
    <>
      <StatusBar style="dark" />
      <SafeAreaView style={styles.container}>
        <View style={styles.imageContainer}>
          <Image
            style={styles.image}
            source={require("../assets/images/photo_of_me.jpg")}
          />
        </View>
        <View style={styles.InformationContainer}>
          <Text style={styles.text}>Johnathan Van Voorhis</Text>
          <Text
            style={styles.text}
            onPress={() =>
              Linking.openURL("mailto:vanvoorhisjohnathan@gmail.com")
            }
          >
            vanvoorhisjohnathan@gmail.com
          </Text>
          <Text
            style={styles.text}
            onPress={() => Linking.openURL("tel:843-516-0406")}
          >
            (843)-516-0406
          </Text>
          <Text
            style={styles.text}
            onPress={() =>
              Linking.openURL(
                "https://github.com/vanvoorhisjohnathan-glitch/IST_236_2026",
              )
            }
          >
            Github Link
          </Text>
        </View>
      </SafeAreaView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#ddd2d2",
    alignItems: "center",
    justifyContent: "center",
  },
  imageContainer: {
    flex: 3,
    paddingTop: 40,
    backgroundColor: "#ddd2d2",
  },
  image: {
    width: 385,
    height: 300,
    resizeMode: "cover",
    borderWidth: 3,
    borderColor: "#ff0000f8",
  },
  InformationContainer: {
    flex: 3,
    backgroundColor: "#ddd2d2",
    alignItems: "center",
    justifyContent: "center",
  },
  text: {
    fontSize: 20,
    marginBottom: 15,
    fontStyle: "italic",
  },
});
