import React from "react";
import { View, Text, Image, Button, StyleSheet } from "react-native";

export default function HomeScreen({ goToRecipes }) {
  return (
    <View style={styles.container}>
      {/* App Title */}
      <Text style={styles.title}>My Recipes App</Text>

      {/* Stock image representing recipes */}
      <Image
        source={require("../assets/recipe-stock.jpg")}
        style={styles.image}
      />

      {/* Navigates to Recipes screen */}
      <Button title="Go To Recipes" onPress={goToRecipes} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center"
  },
  title: {
    fontSize: 24,
    marginBottom: 20
  },
  image: {
    width: 250,
    height: 200,
    marginBottom: 20
  }
});