import React from "react";
import { View, Button, FlatList } from "react-native";
import RecipeItem from "../components/RecipeItem";
import ViewRecipeModal from "./ViewRecipeModal";

export default function RecipesScreen({
  recipes,
  deleteRecipe,
  goHome,
  goToAdd,
  viewRecipe,
  selectedRecipe,
  closeModal
}) {
  return (
    <View style={{ flex: 1, padding: 20 }}>

      {/* Displays list of recipes */}
      <FlatList
        data={recipes}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <RecipeItem
            item={item}
            onView={viewRecipe}
            onDelete={deleteRecipe}
          />
        )}
      />

      {/* Navigation buttons */}
      <Button title="Add Recipe" onPress={goToAdd} />
      <Button title="Home" onPress={goHome} />

      {/* Separate modal component */}
      <ViewRecipeModal
        visible={selectedRecipe !== null}
        recipe={selectedRecipe}
        closeModal={closeModal}
      />
    </View>
  );
}