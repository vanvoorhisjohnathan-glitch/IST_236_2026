import React, { useState } from "react";
import { View, TextInput, Button, StyleSheet } from "react-native";

export default function AddRecipeScreen({ saveRecipe, cancel }) {

  // Local state for user input
  const [title, setTitle] = useState("");
  const [text, setText] = useState("");

  return (
    <View style={styles.container}>

      {/* Input for recipe title */}
      <TextInput
        placeholder="Recipe Title"
        style={styles.input}
        value={title}
        onChangeText={setTitle}
      />

      {/* Input for recipe instructions */}
      <TextInput
        placeholder="Recipe Instructions"
        style={[styles.input, { height: 100 }]}
        value={text}
        onChangeText={setText}
        multiline
      />

      {/* Saves recipe and returns to Recipes screen */}
      <Button
        title="Save"
        onPress={() => saveRecipe(title, text)}
      />

      {/* Returns without saving */}
      <Button title="Cancel" onPress={cancel} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: "center"
  },
  input: {
    borderWidth: 1,
    padding: 10,
    marginBottom: 15
  }
});