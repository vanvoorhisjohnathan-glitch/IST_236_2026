import React from "react";
import { View, Text, Button, Modal, StyleSheet } from "react-native";

export default function ViewRecipeModal({
  visible,
  recipe,
  closeModal
}) {
  return (
    // Modal component controlled by visible prop
    <Modal visible={visible} animationType="slide">
      <View style={styles.container}>
        {/* Only render if recipe exists */}
        {recipe && (
          <>
            <Text style={styles.title}>
              {recipe.title}
            </Text>

            <Text style={styles.text}>
              {recipe.text}
            </Text>

            {/* Close modal button */}
            <Button title="Close" onPress={closeModal} />
          </>
        )}
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20
  },
  title: {
    fontSize: 22,
    marginBottom: 15
  },
  text: {
    marginBottom: 20,
    textAlign: "center"
  }
});