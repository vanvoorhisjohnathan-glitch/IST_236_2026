import React, { useState } from "react";
import { View } from "react-native";
import HomeScreen from "./screens/HomeScreen";
import RecipesScreen from "./screens/RecipesScreen";
import AddRecipeScreen from "./screens/AddRecipeScreen";

export default function App() {
  // Controls which screen is currently displayed
  const [screen, setScreen] = useState("home");

  // Stores all recipe objects
  const [recipes, setRecipes] = useState([]);

  // Stores the recipe selected for viewing in the modal
  const [selectedRecipe, setSelectedRecipe] = useState(null);

  // Adds a new recipe to state
  const addRecipe = (title, text) => {
    const newRecipe = {
      id: Date.now().toString(), // unique id
      title: title,
      text: text
    };

    setRecipes(current => [...current, newRecipe]);
  };

  // Removes a recipe from state
  const deleteRecipe = (id) => {
    setRecipes(current =>
      current.filter(recipe => recipe.id !== id)
    );
  };

  return (
    <View style={{ flex: 1 }}>
      {/* Home Screen */}
      {screen === "home" && (
        <HomeScreen goToRecipes={() => setScreen("recipes")} />
      )}

      {/* Recipes Screen */}
      {screen === "recipes" && (
        <RecipesScreen
          recipes={recipes}
          deleteRecipe={deleteRecipe}
          goHome={() => setScreen("home")}
          goToAdd={() => setScreen("add")}
          viewRecipe={(recipe) => setSelectedRecipe(recipe)}
          selectedRecipe={selectedRecipe}
          closeModal={() => setSelectedRecipe(null)}
        />
      )}

      {/* Add Recipe Screen */}
      {screen === "add" && (
        <AddRecipeScreen
          saveRecipe={(title, text) => {
            addRecipe(title, text);
            setScreen("recipes");
          }}
          cancel={() => setScreen("recipes")}
        />
      )}
    </View>
  );
}