import React from "react";
import { View, Text, Button, StyleSheet } from "react-native";

export default function RecipeItem({ item, onView, onDelete }) {
  return (
    // Displays each recipe in a horizontal row
    <View style={styles.row}>
      <Text style={styles.title}>{item.title}</Text>

      {/* Opens modal */}
      <Button title="View" onPress={() => onView(item)} />

      {/* Deletes recipe from state */}
      <Button title="Delete" onPress={() => onDelete(item.id)} />
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginVertical: 5
  },
  title: {
    flex: 1
  }
});