// screens/HomeScreen.js
import React from 'react';
import { View, Text, Image, StyleSheet, Button, Linking } from 'react-native';
import Title from '../components/Title';
import { COLORS } from '../constants/Theme';

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Image
        source={require('../assets/restaurant.jpg')}
        style={styles.image}
        resizeMode="cover"
      />
      <Title text="Outback Steakhouse" />

      <Text style={styles.link} onPress={() => Linking.openURL('tel:+18432368787')}>
        Phone: +1 843 236 8787
      </Text>
      <Text style={styles.link} onPress={() => Linking.openURL('https://www.outback.com/')}>
        Website
      </Text>
      <Text style={styles.link} onPress={() => Linking.openURL('geo:33.7526165,-78.9614193')}>
        Address
      </Text>

      <View style={{ width: '80%', marginTop: 20 }}>
        <Button title="View Menu" onPress={() => navigation.navigate('Menu')} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: COLORS.background },
  image: { width: '100%', height: 200, marginBottom: 20 },
  link: { color: COLORS.primary, textDecorationLine: 'underline', marginBottom: 5, fontSize: 16 },
});
