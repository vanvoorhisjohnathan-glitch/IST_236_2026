// screens/MenuScreen.js
import React from 'react';
import { View, Text, ScrollView, Button, StyleSheet } from 'react-native';
import MenuItem from '../components/MenuItem';
import { COLORS } from '../constants/Theme';

const menuItems = [
  { name: 'The Bloomin Burger', price: '$14.49', image: require('../assets/burger.jpg') },
  { name: 'Alice Springs Chicken', price: '$20.99', image: require('../assets/chicken.jpg') },
  { name: 'Bloomin Onion', price: '$10.99', image: require('../assets/onion.jpg') },
  { name: 'Steakhouse Salad', price: '$17.99', image: require('../assets/salad.jpg') },
  { name: 'Outback Center Cut Sirloin', price: '$16.99', image: require('../assets/sirloin.jpg') },
];

export default function MenuScreen({ navigation }) {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Menu</Text>

      {menuItems.map((item, index) => (
        <MenuItem key={index} name={item.name} price={item.price} image={item.image} />
      ))}

      <View style={{ marginTop: 20 }}>
        <Button title="Back to Home" onPress={() => navigation.goBack()} />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background, padding: 10 },
  title: { fontSize: 28, color: COLORS.primary, marginBottom: 20, textAlign: 'center' },
});
