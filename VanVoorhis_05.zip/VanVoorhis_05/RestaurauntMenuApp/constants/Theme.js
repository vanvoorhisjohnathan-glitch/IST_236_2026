// constants/Theme.js
export const COLORS = {
  primary: '#8B0000',    // Deep red
  secondary: '#FFA500',  // Orange accent
  background: '#fff',
};

export const FONTS = {
  main: 'System',         // Use system font (no extra loading)
};
