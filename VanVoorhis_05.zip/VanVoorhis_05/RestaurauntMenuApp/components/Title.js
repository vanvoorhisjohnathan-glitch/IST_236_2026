// components/Title.js
import React from 'react';
import { Text, StyleSheet } from 'react-native';
import { COLORS, FONTS } from '../constants/Theme';

export default function Title({ text }) {
  return <Text style={styles.title}>{text}</Text>;
}

const styles = StyleSheet.create({
  title: {
    fontSize: 28,
    fontFamily: FONTS.main,
    color: COLORS.primary,
    marginVertical: 10,
    textAlign: 'center',
  },
});
